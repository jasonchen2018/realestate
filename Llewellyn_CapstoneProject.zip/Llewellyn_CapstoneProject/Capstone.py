#!/usr/bin/env python
# coding: utf-8

# # Python function to find number of schools and top schools in district
# 
# ### Three external libraries required. If running on Jupyter Notebook 
# pip install python-bs4
# pip install beautifulsoup4
# pip install requests
# 
# 
# In this project, I've fetched school data from https://nces.ed.gov/ccd/schoolsearch/ 
# This data set contains schools in all districts in the State of Massachusetts

# In[1]:


import pandas as pd
import numpy as np
import requests
from bs4 import BeautifulSoup #library to scrape website data
import difflib #find difference between files
import matplotlib.pyplot as plt; plt.rcdefaults() #library to plot graphs 
import matplotlib.pyplot as plt


# ### Load dataset into dataframe

# In[2]:


school = pd.read_excel('school_data.xls') #load csv file


# ## data is being fetched from niche.com that has a list of top schools in Massachussets

# In[3]:


def web_scraper(): 
    url = ['https://www.niche.com/k12/search/best-public-middle-schools/s/massachusetts/', 
           'https://www.niche.com/k12/search/best-public-middle-schools/s/massachusetts/?page=2']
    for url_data in url:
        data_source = requests.get(url_data)
        school_data = BeautifulSoup(data_source.content, 'html.parser')
        for headers in school_data.find_all("h2"):
            top_schools = headers.text.strip()
            print(top_schools, file=open("top_schools.txt", "a"))


# In[4]:


def buyer():    
    #fetch school data from buyers current district
    Buyer_district = input("Enter current District: ")
    district_school = school.loc[school['District'] == Buyer_district] #locate rows with district entered by user
    buyer_school = district_school['School Name'] #fetch school names from data set
    buyer_school.to_csv(r'buyer_school.txt', index=None) #save school names to CSV
    print ("Number of Schools: ", len(buyer_school)) #fetch total number of schools in a given district

    #compare top schools and buyer/seller district schools
    with open('buyer_school.txt') as buyer, open('top_schools.txt') as top:
        diff = difflib.Differ().compare(buyer.readlines(), top.readlines()) #diff library checks if file has common strings
        print('\n'.join(diff), file=open("buyer.txt", "w"))

    #loop to fetch top schools from list
    index_list = []
    line_list = []
    with open('buyer.txt') as buyer:
        for index, line in enumerate(buyer):
            line_list.append(line)
            if line.startswith('?'):
                index_list.append(index)

    print ("Schools from District in Top 50 List: \n")
    for index in index_list:
        print (line_list[index-2])


# In[5]:


def seller():
    #fetch school data from sellers district
    seller_district = input("Enter desired District: ")
    district_school = school.loc[school['District'] == seller_district] #locate rows with district entered by user
    seller_school = district_school['School Name'] #fetch school names from data set
    seller_school.to_csv(r'seller_school.txt', index=None) #save school names to CSV
    print ("Number of Schools: ", len(seller_school)) #fetch total number of schools in a given district

    #compare top schools and buyer/seller district schools
    with open('seller_school.txt') as seller, open('top_schools.txt') as top:
        diff = difflib.Differ().compare(seller.readlines(), top.readlines()) #diff library checks if file has common strings
        print('\n'.join(diff), file=open("seller.txt", "w"))
    
    #loop to fetch top schools from list
    index_list = []
    line_list = []
    with open('seller.txt') as seller:
        for index, line in enumerate(seller):
            line_list.append(line)
            if line.startswith('?'):
                index_list.append(index)

    print ("Schools from District in Top 50 List: \n")
    for index in index_list:
        print (line_list[index-2])


# In[6]:


web_scraper()
buyer()
seller()


# In[ ]:




